﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///SessionUser 的摘要说明
/// </summary>
public class SessionUser
{
    public static int tableID;
    public static string userID;
    public static string orderID;
}