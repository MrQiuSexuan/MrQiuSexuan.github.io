﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///myClass 的摘要说明
/// </summary>
public abstract class myClass:IHttpHandler
{

    //封装上下文中的对象
    public HttpContext context
    {
        get
        {
            return HttpContext.Current;
        }
    }
    //请求对象
    public HttpRequest Request
    {
        get
        {
            return context.Request;
        }
    }
    //相应对象
    public HttpResponse Response
    {
        get
        {
            return context.Response;
        }
    }

    public bool IsReusable
    {
        get { return false; }
    }

    public void ProcessRequest(HttpContext context)
    {
        subPR();
    }

    protected abstract void subPR();
}
