﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class 订餐系统UI_manager : System.Web.UI.Page
{
    public int rowIndex;

    public string foodName;
    public double foodPrice;
    public int foodType;
    public string foodPic="菜品/";


    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Insert")
        {
            GridViewRow drv = ((GridViewRow)(((LinkButton)(e.CommandSource)).Parent.Parent)); //此得出的值是表示那行被选中的索引值
            rowIndex = drv.RowIndex;

            GridView1.DataSourceID = "";
            GridView1.DataBind();

            Table GridViewTable = ((Table)GridView1.Controls[0]);       //获取GridView中的DetailsView，并设置pageindex
            DetailsView DetailsView1 = ((DetailsView)GridViewTable.Rows[0].FindControl("DetailsView1"));
            DetailsView1.PageIndex = rowIndex;
        }
    }

    protected void DetailsView1_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
    {
        GridView1.DataSourceID = "SqlDataSource1";
        GridView1.DataBind();
    }
    protected void DetailsView1_ItemCommand(object sender, DetailsViewCommandEventArgs e)
    {
        if (e.CommandName=="Back")
        {
            GridView1.DataSourceID = "SqlDataSource1";
            GridView1.DataBind();
        }
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = DropDownList1.SelectedItem.Value;
        LabelAlert.Text = "";
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox4.Text = DropDownList1.SelectedItem.Value;
    }


    protected void Button3_Click(object sender, EventArgs e)
    {
        Button1.Enabled = true;
        Button2.Enabled = true;
        TextBox2.Enabled = true;
        TextBox3.Enabled = true;
        TextBox4.Text = DropDownList1.SelectedItem.Value;
        FileUpload1.Enabled = true;
        Button3.Enabled = false;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text==""||TextBox3.Text==""||FileUpload1.FileName=="")
        {
            LabelAlert.Text = "数据不能为空";
            return;
        }
        try
        {
            foodName = TextBox2.Text;
            foodPrice = double.Parse(TextBox3.Text);
            foodType = int.Parse(TextBox4.Text);
            foodPic += FileUpload1.FileName;
            upLoadFile();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void upLoadFile()
    {
        bool fileOK = false;
        string path = Server.MapPath("~/订餐系统UI/菜品/");
        if (FileUpload1.HasFile)
        {
            string fileExtension = System.IO.Path.GetExtension(FileUpload1.FileName).ToLower();
            string[] allowedExtensions = { ".gif", ".png", ".bmp", ".jpg" };
            for (int i = 0; i < allowedExtensions.Length; i++)
            {
                if (fileExtension==allowedExtensions[i])
                {
                    fileOK = true;
                }
            }
        }
        if (fileOK)
        {
            try
            {
                FileUpload1.SaveAs(path + FileUpload1.FileName);
                LabelAlert.Text = "文件上传成功<br />";
                //LabelAlert.Text += "<b>原文路径:</b>" + FileUpload1.PostedFile.FileName + "<br/>" + "<b>文件大小：</b>" + FileUpload1.PostedFile.ContentLength + "字节<br/>" + "<b>文件类型：</b>" + FileUpload1.PostedFile.ContentType + "<br/>";
                inserItem(foodName, foodPrice, foodType, foodPic);
                
            }
            catch (Exception)
            {

                LabelAlert.Text = "文件上传不成功";
            }
        }
        else
        {
            LabelAlert.Text = "只能上传图片。";
        }
    }


    public void inserItem(string name, double price, int type, string pic)
    {
        try
        {
            SqlDataSource2.InsertParameters["FoodName"].DefaultValue = name;
            SqlDataSource2.InsertParameters["FoodPrice"].DefaultValue = price.ToString();
            SqlDataSource2.InsertParameters["FoodType"].DefaultValue = type.ToString();
            SqlDataSource2.InsertParameters["FoodPic"].DefaultValue = pic;
            SqlDataSource2.Insert();
            Response.Write("<script>alert('添加成功！')</script>");
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = DropDownList1.SelectedItem.Value;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        var row = GridView2.Rows[e.RowIndex];  // 提取 Id 字段的值 ExtractValuesFromCell方法可以取值
        Image img = (Image)row.FindControl("Image3");
        string path = Server.MapPath("~/订餐系统UI/");
        path += img.ImageUrl.ToString();
        try
        {
            System.IO.FileInfo deleFile = new System.IO.FileInfo(path);
            if (deleFile.Exists)
            {
                deleFile.Delete();
                Response.Write("<script>alert('删除成功！')</script>");
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }

    }
    protected void HyperLink1_Load(object sender, EventArgs e)
    {
        SessionUser.orderID = "";
        SessionUser.tableID = 0;
        SessionUser.userID = "";
    }
}