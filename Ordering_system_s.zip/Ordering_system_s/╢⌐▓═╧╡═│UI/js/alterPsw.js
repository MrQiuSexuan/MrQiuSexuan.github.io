			$(function(){
				$("#checkedBtn").click(function(){
					var userName=$("#userID").val();
					var password=$("#password").val();
					if(userName==""||password=="")
						return;
					$.ajax({
						type:"post",
						url:"../alterPswHandler.ashx",
						async:true,
						data:{
							alterID:userName,
							alertPsw:password,
						},
						success: function(msg){
							if(msg==0){
					     		alert("账号不存在");
					     		$("#userID").val("");
					     		$("#password").val("");
							}
							else{
								alert("修改成功！");
					     		$(window).attr('location','login.html');
							}
					     	
						},
						error:function(xhr){
						   	alert("程序错误，错误信息："+xhr.status);
						}
					});
				});
			});