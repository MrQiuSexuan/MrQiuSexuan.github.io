$(function(){
	$("#loginBtn").click(function(){        //登陆进入
		var userName=$("#userID").val().trim();
		var password=$("#password").val().trim();
		if(userName==""||password=="")
			return;
		$.ajax({
					type:"post",
					url:"../loginHandler.ashx",
					async:true,
					data:{
						userID:userName,
						password:password
					},
					success: function(msg){
						 var arr =msg.split(',');
					     if(arr[0]=="True")
					     {
					     	if(arr[1]=="1"){
					     		alert("登录成功！");
					     		$(window).attr('location','selectTB.html');
					     	}
					     	else if(arr[1]=="2"){
					     		alert("你好，厨师");       //跳转后厨页面
					     		$(window).attr('location','cooking.html');
					     	}
						     	else{
						     		alert("你好，管理人员");     //跳转管理页面
						     		$(window).attr('location','manager.aspx');
						     	}
					     }
					     else
					     {
					     	alert("密码错误，请重新输入.");
					     	$("#userID").val("");
					     	$("#password").val("");
					     }
					   },
					error:function(xhr){
					   	alert("程序错误，错误信息："+xhr.status);
					 }
			});
	})
	
	$("#noLogin").click(function(){            //非登陆进入
		$.ajax({
					type:"post",
					url:"../loginHandler.ashx",
					async:true,
					data:{
						userID:"defaulter",
						password:"defaulter",
					},
					success:function(){
						$(window).attr('location','selectTB.html');
					},
					error:function(xhr){
					   	alert("程序错误，错误信息："+xhr.status);
					}
			})
	})
})
