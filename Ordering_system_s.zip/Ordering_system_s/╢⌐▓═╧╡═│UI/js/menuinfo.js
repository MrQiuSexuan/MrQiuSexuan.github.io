$(function(){
				//建库
				var db;
				window.indexedDB=window.indexedDB||window.mozIndexedDB||window.webkitIndexedDB||window.msIndexedDB;
				if(!window.indexedDB){alert("你的浏览器不支持indexedDB，请更换火狐/chrome浏览器打开.");}
				openDB();//打开数据库
				function openDB(){
		      		var request=window.indexedDB.open("MyDatabase");
		      		request.onsuccess=function(){db=request.result;}
		      		request.onerror=function(){alert("数据库打开错误，错误详情（error:"+request.error+")");}
		      		request.onupgradeneeded=function(event){
		      			db=event.target.result;
		      			var objStore=db.createObjectStore("Data_info",{keyPath:"id",autoIncrement:true});
		      			objStore.createIndex("foodName","foodName",{unique:false});
		      			objStore.createIndex("foodPrice","foodPrice",{unique:false});
		      			objStore.createIndex("foodNum","foodNum",{unique:false});
						objStore.createIndex("foodPic","foodPic",{unique:false});
		      		}
		    	}
				
				//获取各类信息
				
				var img;
				var title;
				var price;
				$("body").delegate("#confirm","click",addData);
				function addData(){
					var num=$(".num").val();
					//获取信息
					//添加数据
					var transaction=db.transaction("Data_info","readwrite");
					var objStore=transaction.objectStore("Data_info");
					var json={foodName:title,foodPrice:price,foodNum:num,foodPic:img}
					var request=objStore.add(json);
					transaction.onerror=function(){
						alert("新增数据出错.(error:"+transaction.error+")");
					};
					alert("已成功添加至订单！");
					$("#infodlg").dialog("close");
				}
				
				//数量设置脚本
				$("body").delegate(".add-plus-input .add","click",function() {
					var $num = $(this).prev(".num");
					var number = $num.attr("value");
					$num.attr("value",parseInt(number) + 1);
				});
				$("body").delegate(".add-plus-input .plus","click",function() {
					var $num = $(this).next(".num");
					var number = $num.attr("value");
					if(number<=1){
						$(".plus").attr("disabled","false");
						 alert("不能再减少啦~");
					}
					else{
						$num.attr("value",parseInt(number) - 1);
					}
				});
				
				
				//选项卡样式
				$("body").delegate(".menuItem li","click",function(){
					$(".menuItem a").removeClass("itemCurrent");
					$(".bodyCurrent").removeClass("bodyCurrent");
					$(this).find("a").addClass("itemCurrent");
					$($(".bodyItem")[$(this).index()]).addClass("bodyCurrent");
				});
				
				
				//点击菜单样式
				$("body").delegate(".bodyItem a","click",infoshow);
				function infoshow(){
					img=$(this).find(".infoimg").attr("src");
					title=$(this).find(".infotitle").text();
					price=$(this).find(".infoprice").text();
					$.mobile.changePage("#infodlg",{});
					$("#dlgContent").find(".infoimg").attr("src",img);
					$("#dlgContent").find(".infotitle").text(title);
					$("#dlgContent").find(".infoprice").text(price);
					$(".num").attr("value",1);
				}
				//点击菜单样式结束
				
				
				$.ajax({
					type:"get",
					url:"../menuinfoHandler.ashx",
					async:true,
					success:function(msg){
						var jsonObj=JSON.parse(msg);
						var conHead = $("#tmpl1").tmpl(jsonObj);
						var conBody=$("#tmpl2").tmpl(jsonObj);
						$("#itemList").append(conHead);
						$(".menuBody").append(conBody);
						showInfo();
					},
					error:function(xhr){
						alert("程序错误，错误信息"+xhr.status);
					}
				})
				
				function showInfo(){
					var $ul_s=$(".menuBody ul");
					$.each($ul_s,function(i,n){
						$.ajax({
							type:"post",
							url:"../menuinfoHandler.ashx",
							async:true,
							data:{ID:n.id},
							success:function(msg){
								var jsonObj=JSON.parse(msg);
								var contant=$("#tmpl3").tmpl(jsonObj);
								$("#"+n.id).append(contant);
								
								$(".menuBody").trigger("create");
								
								$("#1").parent().addClass("bodyCurrent");

							},
							error:function(xhr){
								alert("程序错误，错误信息"+xhr.status);
							}
						})

					})
				}
				
});