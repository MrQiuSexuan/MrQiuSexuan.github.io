$(function(){
				//样式动作的设置
				$("#delbtn").on("click",delShow);
				$("ul li").on("taphold",delShow);
				$("#list").on("click","li .div_btn",delItem);
				
				function delShow(){
					if($(".div_btn").length<=0){
			      		var div_s='<div class="div_btn"><button class=" ui-btn ui-icon-delete ui-btn-icon-notext ui-shadow data-inline=true" ></button></div>';
			      		$("li").prepend(div_s);
			      		$("li a").css("margin-left","40px");
			      		document.getElementById('delbtn').innerHTML="取消";
	      			}
					else{
		      			$(".div_btn").remove();
		      			$("li a").css("margin-left","0px");
		      			document.getElementById('delbtn').innerHTML="删除";
      				}
				}
				//样式动作的设置结束
				
				//数据库打开
				itemList();
				var db;
				function itemList(){
					var request=window.indexedDB.open("MyDatabase");
			      	request.onsuccess=function(event){
			      		db=event.target.result;
			      		itemShow();
			      	}
			      	request.onerror=function(){alert("数据库打开错误，错误详情（error:"+request.error+")");}
			      	request.onupgradeneeded=function(event){
		      			db=event.target.result;
			      	}
				}
				
				function itemShow(){
					$("#list").empty();
					var trans=db.transaction("Data_info","readonly");
		      		var objstore=trans.objectStore("Data_info");
		      		var request=objstore.openCursor();
		      		request.onsuccess=function(){
		      			var cursor=request.result;
		      			if(cursor){
						note="<li id='"+cursor.value.id+"'><a><img class='Img' src='"+cursor.value.foodPic+"'/><h2>"+cursor.value.foodName+"</h2><div class='div_num'>数量：<span class='li_num'>"+cursor.value.foodNum+"</span></div><h3>￥<span class='li_price'>"+cursor.value.foodPrice+"</span></h3></a></li>";
	      				$("#list").append(note);
	      				$("#list").listview('refresh');
		      			cursor.continue();
		      			setPrice();
		      			}
		      		}
				}
				
				function delItem(){
		      		var result=confirm("确定要执行删除？");
		      		if(result){
		      			var value=parseInt($(this).parent("li").attr("id"));
		      			var trans=db.transaction("Data_info","readwrite");
		      			var objStore=trans.objectStore("Data_info");
		      			var requery=objStore.delete(value);
		      			requery.onsuccess=function(){
		      				$("li").remove("#"+value);
		      				setPrice();
		      			}
		      		}
		      		else return;
	      		}
				
				
	
				//设置总价格
				function setPrice(){
					var sumPrice=0.0;
					var li_s=$("ul li");
					$.each(li_s, function(i,n) {
						var $li=$(n);
						var num=parseFloat($li.find(".li_num").text());
						var price=parseFloat($li.find(".li_price").text());
						sumPrice+=num*price;
					})
					$(".sumprice").text(sumPrice);
				}
				
				
				
				// 点击 <span> (x), 关闭弹窗
				$(".close").click(function close() {
				   $("#myModal").css("display","none");
				   $("#footer").css("display","block");
				});
				$(".orderbtn").click(function(){
					if($("#list li").length==0)
					{
						return;
					}
					else
					{
						$("#footer").css("display","none");
						$("#myModal").css("display","block");
						$("#pay").text($(".sumprice").text());
					}
				});
				
				$("#onlinePay").click(function(){
					alert("跳转下单~~~~~");
					subOrder();
					 $(".close").trigger("click");
				});
				$("#cashPay").click(function(){
					alert("正在呼叫人工，请稍候~~~~~");
					subOrder();
					 $(".close").trigger("click");
				});
				
				
				function subOrder(){
					var totlePrice=$(".sumprice").text();
					var date = new Date();
					var newyear = date.getFullYear();
					var newmonth = date.getMonth() + 1; 
					newmonth = (newmonth<10 ? "0"+newmonth:newmonth);
					var day = date.getDate();
					var hours=date.getHours();
					var minu=date.getMinutes();
					var sec=date.getSeconds();
					var newdate =newyear+ newmonth + day+hours+minu+sec;
					//生成流水号
					var trans=db.transaction("Data_info","readonly");
		      		var objstore=trans.objectStore("Data_info");
		      		var request=objstore.openCursor();
		      		request.onsuccess=function(){
		      			var cursor=request.result;
		      			if(cursor){
							$.ajax({
								type:"post",
								url:"../orderHandler.ashx",
								async:true,
								data:{
									dataName:cursor.value.foodName,
									dataNum:cursor.value.foodNum,
									dataPrice:cursor.value.foodPrice,
									dataTime:newdate,  //流水号
								},
								error:function(xhr){
									alert("程序错误1，错误信息"+xhr.status);
								}
							});
		      			cursor.continue();
		      			}
		      			
		      		}
					$.ajax({
						type:"post",
						url:"../orderHandler.ashx",
						async:true,
						data:{
							orderID:newdate,	//流水号
							sumPrice:totlePrice,
						},
						success:function(){
							clearindexedDB();//清空数据库的指令
						},
						error:function(xhr){
							alert("程序错误2，错误信息"+xhr.status);
						}
					});
		      			$("#list").empty();
						setPrice();
				}
				
				function clearindexedDB(){ //清空indexedDB数据库
					var trans=db.transaction("Data_info","readwrite");
		      		var objstore=trans.objectStore("Data_info");
		      		objstore.clear();
				}
				
});