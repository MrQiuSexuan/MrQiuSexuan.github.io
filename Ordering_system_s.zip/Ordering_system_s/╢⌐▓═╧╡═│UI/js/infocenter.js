$(function(){
				$.ajax({
				type:"get",
				url:"../iCenterHandler.ashx",
				async:true,
				success:function(msg){
					showInfo(msg);
				},
				error:function(xhr){
					alert("程序错误，错误信息"+xhr.status);
				},
			});
			
			function showInfo(msg){
				var msgArr=msg.split('/');
				$.each(msgArr, function(i,n) {
					if(i%2==0)
					{
						var jsonHead=JSON.parse(msgArr[i]);
						var conHead=$("#tmpl4").tmpl(jsonHead);
						$("#contant").append(conHead);
					}
					else
					{
						var jsonBody=JSON.parse(msgArr[i]);
						var conBody=$("#tmpl5").tmpl(jsonBody);
						$("#contant div").append(conBody);
					}
				})
				$("#contant").trigger("create");
			}
});
