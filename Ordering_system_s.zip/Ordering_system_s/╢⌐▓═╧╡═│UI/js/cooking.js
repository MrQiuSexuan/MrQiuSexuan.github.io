$(function(){
	showItem();
	
	setInterval(showItem,10000);
	function showItem(){
		$("#list").empty();
		$.ajax({
			type:"get",
			url:"../cookingHandler.ashx",
			async:true,
			success:function(msg){
				var jsonObj=JSON.parse(msg);
				var con=$("#tmpl6").tmpl(jsonObj);
				$("#list").append(con);
				$("#list").trigger("create");
			},
			error:function(xhr){
				alert("程序错误，错误信息:"+xhr.status);
			}
		});
	}
	
	
	$("#delbtn").on("click",delShow);
	$("#list").on("click","li .div_btn",delItem);
	
	function delShow(){
		if($(".div_btn").length<=0){
      		var div_s='<div class="div_btn"><button class=" ui-btn ui-icon-delete ui-btn-icon-notext ui-shadow data-inline=true" ></button></div>';
      		$("li").prepend(div_s);
      		$("li a").css("margin-left","40px");
      		document.getElementById('delbtn').innerHTML="取消";
		}
		else{
			$(".div_btn").remove();
			$("li a").css("margin-left","0px");
			document.getElementById('delbtn').innerHTML="删除";
		}
	}
	
	
	function delItem(){
  		var result=confirm("确定要执行完成操作？");
  		if(result){
  			var value=parseInt($(this).parent("li").attr("id"));
  			$.ajax({
  				type:"post",
  				url:"../cookingHandler.ashx",
  				async:true,
  				data:{
  					delID:value,
  				},
  				success:function(msg){
  					if(msg=="True")
  					{
  						$("li").remove("#"+value);
  					}
  				},
				error:function(xhr){
					alert("程序错误，错误信息:"+xhr.status);
				}
  		});
  		}
  		else return;
	}
	
	
	$("#outbtn").click(function(){
		$(window).attr("location","index.html");
	})
	
	
})
