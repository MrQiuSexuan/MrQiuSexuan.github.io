$(document).ready(function(){
    			
    			//iframe高度
    			var h=$(window).height();
    			var h1=$("#header").height();
    			var h2=$("#footer").height();
    			h=(h-h1-h2-44);
    			$("#myIframe").css("height",h);
    			
    			//导航条点击
    			$(".nav li").click(function(){
    				var i=$(this).index();
    				if(i==1){
    					$("#myIframe").attr("src","order.html");
    				}
    				else if(i==2){
    					$("#myIframe").attr("src","infocenter.html");
    				}
    				else{
    					$("#myIframe").attr("src","menuinfo.html");
    				}
    			});
    			
    			$("#callServer").click(function(){
    				alert("正在呼叫服务员~~~");
    			})
    			
    			
    			//会员
    			$.ajax({
    				type:"GET",
					url:"../mainindexHandler.ashx",
					async:true,
					success: function(msg){
						var jsonObj=JSON.parse(msg);
						$("#vipName").html(jsonObj[0].UserID);//UserID
						$("#discount").html(jsonObj[0].Discount);//Discount
					   },
					error:function(xhr){
					   	alert("程序错误，错误信息："+xhr.status);
					 }
    			})
    			//桌号
    			$.ajax({
    				type:"POST",
					url:"../mainindexHandler.ashx",
					async:true,
					success: function(msg){
					     $("#tableHead").html(msg);
					   },
					error:function(xhr){
					   	alert("程序错误，错误信息："+xhr.status);
					 }
    			})
    			
    			$("#outLogin").click(function(){
    				$(window).attr("location","index.html");
    			})
    			
});