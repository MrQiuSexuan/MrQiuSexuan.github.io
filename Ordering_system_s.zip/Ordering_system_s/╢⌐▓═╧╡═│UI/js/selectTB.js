$(function(){
			var height=$(window).height();
			$(".content").offset({
				top:height/1.4       //设置中间内容的高度
			});
			tabNum=0;			    //初始桌数0
			
			$.ajax({                //查询桌表
					type:"get",
					url:"../tableClient.ashx",
					async:true,
					success: function(msg){
						tabNum=parseInt(msg);
					},
					error:function(xhr){
						alert("程序错误1，错误信息："+xhr.status);
					},
				});
				
			$("#tabBtn").click(function(){                	//提交桌号按钮
				var tabid=parseFloat($("#tableID").val());
				if(tabid<=0||tabid>tabNum||isNaN(tabid)){    //判断输入数据是否正确
					alert("输入错误");
					return;
				}
				else
				{
					$.ajax({
						type:"post",
						url:"../tableClient.ashx",
						async:true,
						data:{
							tableID:tabid,
						},
						success: function(){
							$(window).attr('location','mainindex.html');
						},
						error:function(xhr){
							alert("程序错误2，错误信息："+xhr.status);
						},
					});
				}
			})
})