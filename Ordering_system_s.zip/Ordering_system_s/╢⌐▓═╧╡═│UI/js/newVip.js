$(function(){
				$("#checkedBtn").click(function(){
					var userName=$("#userID").val();
					var password=$("#password").val();
					if(userName==""||password=="")
						return;
					$.ajax({
						type:"post",
						url:"../newVipHandler.ashx",
						async:true,
						data:{
							newName:userName,
							newPsw:password
						},
						success: function(msg){
							if(msg==0){
								alert("注册成功！");
					     		$(window).attr('location','login.html');
							}
							else {
								alert("账号冲突,请重新输入,建议：输入手机号码");
								$("#userID").val("");
								$("#password").val("");
							}
					    },
						error:function(xhr){
						   	alert("程序错误，错误信息："+xhr.status);
						}
					});
				})
})